<template>
    <nav>
        <div>Home</div>
        <div>Über mich</div>
        <div>Kontakt</div>
    </nav>
</template>

<script>
export default {

};
</script>

<style>

nav {
    display: flex;
    flex-direction: row;
    justify-content: center;
    gap: 20px;
    padding: 30px 0;
}

nav div {
    font-size: 1.5rem;
}

</style>
